var w = require('./writer');

w.writeData();