
let greeter =  (firstName, lastName) => {
    console.log(`Hello  ${firstName} ${lastName}`);
}

greeter("John", "Smith");

