var booksModule = require('./books');
var videosModule = require('./videos');

module.exports = {
    booksModule: booksModule,
    videosModule: videosModule
}